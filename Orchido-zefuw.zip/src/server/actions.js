import HttpError from '@wasp/core/HttpError.js'

export const createUser = async ({ username, password }, context) => {
  const user = await context.entities.User.create({
    data: {
      username,
      password
    }
  });

  return user;
}

export const createAgency = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const { name, address, country, phoneNumber, userId } = args;

  const agency = await context.entities.Agency.create({
    data: {
      name,
      address,
      country,
      phoneNumber,
      userId
    }
  });

  const user = await context.entities.User.findUnique({
    where: { id: userId }
  });

  await context.entities.User.update({
    where: { id: userId },
    data: {
      agencies: { connect: { id: agency.id } }
    }
  });

  return agency;
}

export const createWorker = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const { name, phoneNumber, age, passportPhoto, experience, personalPhoto, agencyId, userId } = args;

  const agency = await context.entities.Agency.findUnique({
    where: { id: agencyId }
  });

  if (!agency) { throw new HttpError(404, 'Agency not found') };

  const worker = await context.entities.Worker.create({
    data: {
      name,
      phoneNumber,
      age,
      passportPhoto,
      experience,
      personalPhoto,
      agency: { connect: { id: agencyId } },
      createdBy: { connect: { id: userId } }
    }
  });

  await context.entities.Agency.update({
    where: { id: agencyId },
    data: { workers: { connect: { id: worker.id } } }
  });

  return worker;
}

export const updateStep = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const step = await context.entities.Step.findUnique({
    where: { id: args.stepId }
  })
  if (step.worker.userId !== context.user.id) { throw new HttpError(403) }

  return context.entities.Step.update({
    where: { id: args.stepId },
    data: { status: args.status }
  })
}

export const createBill = async (args, context) => {
  // Implementation goes here
}
