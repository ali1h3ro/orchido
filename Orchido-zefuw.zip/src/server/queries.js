import HttpError from '@wasp/core/HttpError.js'

export const getUser = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const { id } = args;

  const user = await context.entities.User.findUnique({
    where: { id },
  });

  if (!user) throw new HttpError(404, 'No user with id ' + id);

  return user;
}

export const getAgency = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const agency = await context.entities.Agency.findUnique({
    where: { id: args.id },
    include: { workers: true }
  });

  if (!agency) throw new HttpError(404, 'No agency with id ' + args.id);

  return agency;
}

export const getWorker = async ({ id }, context) => {
  if (!context.user) {
    throw new HttpError(401);
  }

  const worker = await context.entities.Worker.findUnique({
    where: { id },
    include: {
      agency: true,
      createdBy: true
    }
  });

  if (!worker) {
    throw new HttpError(404, 'No worker with id ' + id);
  }

  return worker;
}

export const getStep = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  const step = await context.entities.Step.findUnique({
    where: { id: args.id },
    include: {
      worker: {
        include: {
          agency: true,
          createdBy: true
        }
      },
      updatedBy: true
    }
  })

  if (!step) { throw new HttpError(404, 'No step with id ' + args.id) }

  return step
}

export const getBill = async ({ id }, context) => {
  const bill = await context.entities.Bill.findUnique({
    where: { id },
    include: { worker: true }
  });

  if (!bill) throw new HttpError(404, 'No bill with id ' + id);

  return bill;
}