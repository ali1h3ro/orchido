import React from 'react';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import createWorker from '@wasp/actions/createWorker';

export function WorkersPage() {
  const { data: workers, isLoading, error } = useQuery(getWorkers);
  const createWorkerFn = useAction(createWorker);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateWorker = () => {
    createWorkerFn({
      name: 'John Doe',
      phoneNumber: '1234567890',
      age: 25,
      passportPhoto: 'path/to/passportPhoto.jpg',
      experience: '5 years',
      personalPhoto: 'path/to/personalPhoto.jpg',
      agencyId: 1
    });
  };

  return (
    <div className='p-4'>
      <div className='flex justify-end mb-4'>
        <button
          onClick={handleCreateWorker}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          Create Worker
        </button>
      </div>
      {workers.map((worker) => (
        <div
          key={worker.id}
          className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'
        >
          <div>{worker.name}</div>
          <div>{worker.phoneNumber}</div>
          <div>{worker.age}</div>
          <div>{worker.experience}</div>
          <div>{worker.agency.name}</div>
        </div>
      ))}
    </div>
  );
}