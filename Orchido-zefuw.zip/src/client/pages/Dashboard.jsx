import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import getUser from '@wasp/queries/getUser';
import getAgency from '@wasp/queries/getAgency';
import getWorker from '@wasp/queries/getWorker';
import getStep from '@wasp/queries/getStep';
import getBill from '@wasp/queries/getBill';

export function DashboardPage() {
  const { data: user } = useQuery(getUser);
  const { data: agencies } = useQuery(getAgency);
  const { data: workers } = useQuery(getWorker);
  const { data: steps } = useQuery(getStep);
  const { data: bills } = useQuery(getBill);

  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-4'>Dashboard</h1>

      <div className='bg-gray-100 p-4 rounded-lg mb-4'>
        <h2 className='text-xl font-bold mb-2'>User Information</h2>
        <p>Username: {user.username}</p>
        <p>Role: {user.role}</p>
      </div>

      <div className='bg-gray-100 p-4 rounded-lg mb-4'>
        <h2 className='text-xl font-bold mb-2'>Agencies</h2>
        {agencies.map((agency) => (
          <div key={agency.id} className='mb-2'>
            <Link to={`/agency/${agency.id}`} className='text-blue-500 hover:underline'>
              {agency.name}
            </Link>
          </div>
        ))}
      </div>

      <div className='bg-gray-100 p-4 rounded-lg mb-4'>
        <h2 className='text-xl font-bold mb-2'>Workers</h2>
        {workers.map((worker) => (
          <div key={worker.id} className='mb-2'>
            <Link to={`/worker/${worker.id}`} className='text-blue-500 hover:underline'>
              {worker.name}
            </Link>
          </div>
        ))}
      </div>

      <div className='bg-gray-100 p-4 rounded-lg mb-4'>
        <h2 className='text-xl font-bold mb-2'>Steps</h2>
        {steps.map((step) => (
          <div key={step.id} className='mb-2'>
            <Link to={`/step/${step.id}`} className='text-blue-500 hover:underline'>
              {step.name}
            </Link>
          </div>
        ))}
      </div>

      <div className='bg-gray-100 p-4 rounded-lg mb-4'>
        <h2 className='text-xl font-bold mb-2'>Bills</h2>
        {bills.map((bill) => (
          <div key={bill.id} className='mb-2'>
            <Link to={`/bill/${bill.id}`} className='text-blue-500 hover:underline'>
              {bill.name}
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}