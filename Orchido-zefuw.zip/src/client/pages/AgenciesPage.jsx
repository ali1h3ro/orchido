import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';

export function AgenciesPage() {
  const { data: agencies, isLoading, error } = useQuery(getAgencies);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      {agencies.map((agency) => (
        <div
          key={agency.id}
          className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'
        >
          <div>{agency.name}</div>
          <div>{agency.workers.length} Workers</div>
          <div>
            <Link
              to={`/agency/${agency.id}`}
              className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'
            >
              View Details
            </Link>
          </div>
        </div>
      ))}
    </div>
  );
}