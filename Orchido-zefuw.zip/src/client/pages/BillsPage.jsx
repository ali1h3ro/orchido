import React from 'react';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getBill from '@wasp/queries/getBill';
import createBill from '@wasp/actions/createBill';

export function BillsPage() {
  const { data: bills, isLoading, error } = useQuery(getBill);
  const createBillFn = useAction(createBill);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleCreateBill = () => {
    createBillFn(/* bill data */);
    // handle any necessary state updates
  };

  return (
    <div>
      {bills.map((bill) => (
        <div key={bill.id}>
          <p>{bill.name}</p>
          <p>{bill.amount}</p>
        </div>
      ))}
      <button onClick={handleCreateBill}>Create Bill</button>
    </div>
  );
}