import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getStep from '@wasp/queries/getStep';
import updateStep from '@wasp/actions/updateStep';

export function StepsPage() {
  const { data: step, isLoading, error } = useQuery(getStep);
  const updateStepFn = useAction(updateStep);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateStep = (status) => {
    updateStepFn({ stepId: step.id, status });
  };

  return (
    <div>
      <h1>Steps Page</h1>
      <p>Status: {step.status}</p>
      <button onClick={() => handleUpdateStep('Completed')}>Complete Step</button>
      <Link to='/dashboard'>Go to Dashboard</Link>
    </div>
  );
}